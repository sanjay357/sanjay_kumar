from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
import logging
import pytest

def setup():
    
    global driver
    global url
    global username
    global password
    global username_xpath
    global password_xpath
    global login_button_xpath
    global delivery_list_tab_xpath

    options = Options()
    options.headless = True
    driver = webdriver.Chrome(executable_path='./drivers/chromedriver', options=options)
    url="http://s4-integration.trt.mes.bshg.com/production-info"
    username="kuruba"
    password="Welcome@10"
    username_xpath="/html/body/div/div[2]/div/div/div/div/form/div[1]/input"
    password_xpath="/html/body/div/div[2]/div/div/div/div/form/div[2]/input"
    login_button_xpath="/html/body/div/div[2]/div/div/div/div/form/div[4]/input"
    delivery_list_tab_xpath="/html/body/app-root/div/div[1]/app-header/div/ul/li[3]/a"




def login():
    time.sleep(3)
    driver.get(url)
    time.sleep(3)
    driver.find_element_by_xpath(username_xpath).send_keys(username)
    driver.find_element_by_xpath(password_xpath).send_keys(password)

    driver.find_element_by_xpath(login_button_xpath).click()
    time.sleep(4)

def wait_until_spinner_disappears_on_page():
    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located(
            (By.XPATH, "//div[contains(@class,'ngx-overlay') and "
             + "not(contains(@class,'loading-foreground')) and not(contains(@class,'foreground-closing'))]")))

#SF-365
def test_get_delivery_filter_by_order_number():
    login()
    wait_until_spinner_disappears_on_page()
    #To click delevery list tab 
    driver.find_element_by_xpath(delivery_list_tab_xpath).click()
    wait_until_spinner_disappears_on_page()
    #Filter
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header/span[1]/mat-panel-title").click()
    #Get order number
    order_number=driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[5]/span").text
    print (order_number)
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[1]/div[2]/mat-form-field/div/div[1]/div/input").send_keys(order_number)
    
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[2]/span").click()
    
    wait_until_spinner_disappears_on_page()

    deliveryListCountBeforeFilter=driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    
    OrderNumberElements = driver.find_elements_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[5]/span")
    print (OrderNumberElements)
    if len(OrderNumberElements) > 0:
        actualOrderNumberDisplayed = [
            element.text for element in OrderNumberElements]

        for actualOrderNumber in actualOrderNumberDisplayed:
            print (actualOrderNumber)
            assert actualOrderNumber == order_number
        else:
            assert True
    wait_until_spinner_disappears_on_page()     
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header/span[1]/mat-panel-title").click
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[1]/span").click()
        
    wait_until_spinner_disappears_on_page()   
    
    deliveryListAfterFilterReset = driver.find_element_by_xpath(
            "/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    assert deliveryListCountBeforeFilter == deliveryListAfterFilterReset
#SF-367    
def test_get_material_list_comparison_result_from_the_order_list_in_mes_product_info():
    login()
    wait_until_spinner_disappears_on_page()     
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[1]/mat-checkbox/label/div").click() 
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[2]/td[1]/mat-checkbox/label/div").click()    
 
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[1]/div[1]/button/span").click()      
    time.sleep(60)

#SF-368
def test_check_delevery_list_info():
    login()
    wait_until_spinner_disappears_on_page()
    #To click delevery list tab 
    driver.find_element_by_xpath(delivery_list_tab_xpath).click()
    wait_until_spinner_disappears_on_page()
    for row in range(2,9):
        for col in range (3,20):
            count =len(driver.find_elements_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td["+str(col)+"]"))
           
            if count > 0:
                assert True
            else:
                assert False    

#SF-374
def test_check_accessibility_pages_in_mes_prduction_info():
    login()
    wait_until_spinner_disappears_on_page()
    #To click delevery list tab 
    driver.find_element_by_xpath(delivery_list_tab_xpath).click()
    wait_until_spinner_disappears_on_page()
    element=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[1]/button/span").text
    if len(element) !=0:
        assert True
    else:
        assert False
    #Next page    
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-paginator/div/div/div[2]/button[3]").click()
    wait_until_spinner_disappears_on_page()
    #Last page
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-paginator/div/div/div[2]/button[4]").click()
    wait_until_spinner_disappears_on_page()
    #Previous page
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-paginator/div/div/div[2]/button[2]").click()
    wait_until_spinner_disappears_on_page()
    #First page
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-paginator/div/div/div[2]/button[1]").click()
    time.sleep(30)
#SF-382
def test_start_status_field_in_mes_production_info():
    login()
    wait_until_spinner_disappears_on_page()
    #To click delevery list tab 
    driver.find_element_by_xpath(delivery_list_tab_xpath).click()
    wait_until_spinner_disappears_on_page()
    #click sort
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[4]/div/button").click()
    wait_until_spinner_disappears_on_page()
    deliverystatusSortedAscending = [str(ele.text) for ele in driver.find_elements_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[4]")]
        
    # assert delivery status ascending order sorting
    assert deliverystatusSortedAscending == sorted(deliverystatusSortedAscending)
    
    #click sort


    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[4]/div/button").click()
    wait_until_spinner_disappears_on_page()

    deliverystatusSortedDescending = [str(ele.text) for ele in driver.find_elements_by_xpath(
            "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[4]")]

    # assert delivery status descending order sorting
    
    assert deliverystatusSortedDescending == sorted(
        deliverystatusSortedDescending, reverse=True)


#not completed
#SF-383
def check_manual_order_synchronitation_in_mes_production_info():
    login()
    wait_until_spinner_disappears_on_page()

    ordernumber=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[1]/span").text
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[1]/div[1]/mat-form-field/div/div[1]/div/input").clear()
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[1]/div[1]/mat-form-field/div/div[1]/div/input").send_keys(ordernumber)
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[1]/div[2]/button").click()
    
    #alertmessage = driver.switch_to_alert
    alert = WebDriverWait(driver, 5).until(EC.alert_is_present())
    alertmessage = alert.text
    print(alertmessage)
    #print(alertmessage.text)
    assert alertmessage == "Order Synchronization started"

#SF-387
def test_get_list_of_filtered_order_by_status_in_mes_manufacturing_parts():
    login()
    wait_until_spinner_disappears_on_page()
    status_dropdown_xpath="/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[3]/div[2]/mat-form-field/div/div[1]/div/mat-select"
    
    apply_button_xpath="/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[2]"
    status_element_xpath="/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[10]"
    #To click manudaacturing tab 
    driver.find_element_by_xpath("/html/body/app-root/div/div[1]/app-header/div/ul/li[1]/a").click()
    wait_until_spinner_disappears_on_page()
    beforefilterProOrderNo=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    #Filter tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header").click()
    
    for i in range(21,27): 
        time.sleep(1)
        #For reset filter   
        if(i==26):
            driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[1]").click()
            wait_until_spinner_disappears_on_page()
            afterclickNoneProOrderNo=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
            
            assert beforefilterProOrderNo == afterclickNoneProOrderNo
            time.sleep(1)
        else:
            assert True    


        driver.find_element_by_xpath(status_dropdown_xpath).click()
        driver.find_element_by_xpath("//*[@id='mat-option-"+str(i)+"']").click()
        driver.find_element_by_xpath(apply_button_xpath).click()
        wait_until_spinner_disappears_on_page()

        
        #Get Ready list
        statusElements = driver.find_elements_by_xpath(status_element_xpath)
        if len(statusElements) > 0:

            if i==21:
                statusStorage = [
                    str(ele.text) for ele in statusElements]

                for actualStatus in statusStorage:
                    assert actualStatus == "Ready"      
            elif i==22:
                statusStorage = [
                    str(ele.text) for ele in statusElements]

                for actualStatus in statusStorage:
                    assert actualStatus == "Assembly"
            elif i==23:

                statusStorage = [
                    str(ele.text) for ele in statusElements]

                for actualStatus in statusStorage:
                    assert actualStatus == "Finished"

               
            elif i==24:
                statusStorage = [
                    str(ele.text) for ele in statusElements]

                for actualStatus in statusStorage:
                    assert actualStatus == "Break"
            elif i==25:
                
                statusStorage = [
                    str(ele.text) for ele in statusElements]

                for actualStatus in statusStorage:
                    assert actualStatus == "Deleted"

                
            elif i==26:
                 
                statusStorage = [
                    str(ele.text) for ele in statusElements]

                for actualStatus in statusStorage:
                    assert actualStatus == "NotSynchronized"
                  
            else:
                assert True        
        else:
            assert True  
    #To click none
    driver.find_element_by_xpath(status_dropdown_xpath).click()
    driver.find_element_by_xpath("//*[@id='mat-option-20']").click()
    driver.find_element_by_xpath(apply_button_xpath).click()
    wait_until_spinner_disappears_on_page()
    afterclickNoneProOrderNo=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    assert beforefilterProOrderNo == afterclickNoneProOrderNo
    
#SF-393
def test_check_general_data_in_details_tab_mes_production_info():
    login()
    
    wait_until_spinner_disappears_on_page()
    #Filter
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header/span[1]/mat-panel-title").click()
    #Get order number
    order_number=driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[1]").text
    
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[1]/div[3]/mat-form-field/div/div[1]/div/input").send_keys(order_number)
    
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[2]/span").click()
    
    wait_until_spinner_disappears_on_page()
    orderNumberAfterFilter=driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[1]").text
    assert    order_number == orderNumberAfterFilter
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[13]/a").click()
    wait_until_spinner_disappears_on_page()
    #To check production order info
    
    for i in range(2,5,2):
        if(i==2):
            for c in range(1,5):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[2]/div["+str(c)+"]/div[2]")
                assert len(value.text) > 0
        elif(i==4):
            for c in range(1,5):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[2]/div["+str(c)+"]/div[4]")
                
                assert len(value.text) > 0   
    #Check the information under General tab    
    for c in range(1,5):
            content =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div["+str(c)+"]/div/mat-card/mat-card-content")
    
            assert len(content.text) > 0               
    #Check the information listed below General -Production Data
    
    for i in range(2,5,2):
        if(i==2):
            for c in range(1,5):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[1]/div/mat-card/mat-card-content/div["+str(c)+"]/div[2]")
                assert len(value.text) > 0
        elif(i==4):
            for c in range(1,4):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[1]/div/mat-card/mat-card-content/div["+str(c)+"]/div[4]")
                
                assert len(value.text) > 0     
    #Check the information listed below General -Date/Times
    for i in range(2,5,2):
        if(i==2):
            for c in range(1,3):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[2]/div/mat-card/mat-card-content/div["+str(c)+"]/div[2]")
                assert len(value.text) > 0
        elif(i==4):
            
            value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[2]/div/mat-card/mat-card-content/div[1]/div[4]")
            
            assert len(value.text) > 0  

    #Check the information listed below General - Assignment
    for i in range(2,5,2):
        if(i==2):
            for c in range(1,3):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[3]/div/mat-card/mat-card-content/div["+str(c)+"]/div[2]")
                assert len(value.text) > 0
        elif(i==4):
            for c in range(1,3):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[3]/div/mat-card/mat-card-content/div["+str(c)+"]/div[4]")
                
                assert len(value.text) > 0  
    #Check the information listed below General - Administration
    for i in range(2,5,2):
        if(i==2):
            for c in range(1,3):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[4]/div/mat-card/mat-card-content/div["+str(c)+"]/div[2]")
                assert len(value.text) > 0
        elif(i==4):
            for c in range(1,3):
                value =driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-tab-group/div/mat-tab-body[1]/div/div[4]/div/mat-card/mat-card-content/div["+str(c)+"]/div[4]")
                
                assert len(value.text) > 0     
#SF-398
def test_check_create_internal_mes_order():
    login()
    wait_until_spinner_disappears_on_page()
    #Click on Create internal MES Order
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[2]/div/button").click()
    
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[2]/button[1]").click()
    #Click on Create internal MES Order
    time.sleep(1)
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[2]/div/button").click()
    
    driver.find_element_by_xpath("//*[@id='mat-select-4']").click()
    #Enter the value in Material field
    driver.find_element_by_xpath("//*[@id='mat-option-21']").click()
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[1]/form/div[2]/mat-form-field/div/div[1]/div/input").send_keys("steel")
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[1]/form/div[3]/mat-form-field/div/div[1]/div/input").send_keys("1")
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[1]/form/div[4]/mat-form-field/div/div[1]/div/input").send_keys("2")
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[1]/form/div[5]/mat-form-field/div/div[1]/div/input").send_keys("Bangalore")
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[1]/form/div[6]/mat-form-field/div/div[1]/div/input").send_keys("Chennai")
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[1]/form/div[7]/mat-form-field/div/div[1]/div[2]/mat-datepicker-toggle/button").click()
    driver.find_element_by_xpath("/html/body/div[3]/div[4]/div/mat-datepicker-content/mat-calendar/div/mat-month-view/table/tbody/tr[4]/td[4]/div").click()
    #Click the button Create Order
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-dialog-container/app-create-internal-order-dialog/div[2]/button[2]").click()


#SF-403
def test_get_a_list_of_filtered_order_by_start_date():
    login()
    wait_until_spinner_disappears_on_page()
    #Click on Manufacturing of Parts Tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[1]/app-header/div/ul/li[1]/a").click() 
    wait_until_spinner_disappears_on_page()
    orderbeforefilter=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    #filter tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header").click() 
    time.sleep(1)
    #Click the calendar icon in the Start date to field
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[2]/div[1]/mat-form-field/div/div[1]/div[2]/mat-datepicker-toggle/button").click() 
    monthBeforeChange=driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-month-view/table/tbody/tr[1]/td").text
    #left click
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/mat-calendar-header/div/div/button[2]").click()
    monthafterChange=driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-month-view/table/tbody/tr[1]/td").text
    assert monthBeforeChange != monthafterChange
    #Right click
    monthBeforeChange=driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-month-view/table/tbody/tr[1]/td").text
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/mat-calendar-header/div/div/button[3]").click()
    monthafterChange=driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-month-view/table/tbody/tr[1]/td").text
    assert monthBeforeChange != monthafterChange
    #Select year
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/mat-calendar-header/div/div/button[1]").click() 
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-multi-year-view/table/tbody/tr[2]/td[2]").click() 
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-year-view/table/tbody/tr[3]/td[1]").click() 
    driver.find_element_by_xpath("/html/body/div[3]/div[2]/div/mat-datepicker-content/mat-calendar/div/mat-month-view/table/tbody/tr[3]/td[4]").click() 
    
    originalDate=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[2]/div[1]/mat-form-field/div/div[1]/div[1]/input").text
    print (originalDate)
    #filter

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[2]").click() 
    wait_until_spinner_disappears_on_page()

    # Read Start times of all the Orders displayed
    startDateElements = [ele for ele in driver.find_elements_by_xpath(
            "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[11]/span")]
    if len(startDateElements) > 0:
        startDateList = []

        # loop through and add StartDateTime to a list
        for starDateElement in startDateElements:
            dt = datetime.strptime(
            starDateElement.text.replace(",", "")[0:10],"%m/%d/%Y" )
            startDateList.append(dt)

        for sdt in startDateList:
                assert sdt.date() ==originalDate
    else:
            
            assert True        

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[1]").click()            
    wait_until_spinner_disappears_on_page()
    orderafterfilter=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    assert orderafterfilter == orderbeforefilter



#SF-410
def test_check_order_button_in_details_tab():
    login()
    wait_until_spinner_disappears_on_page()
    orderNumberBeforeFilter=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[1]/span").text
    #Filter tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header").click()

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[1]/div[3]/mat-form-field/div/div[1]/div/input").send_keys(orderNumberBeforeFilter)
    #Apply filter
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[2]").click()
    wait_until_spinner_disappears_on_page()
    orderNoAfterFilter=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[1]/span").text
    assert orderNoAfterFilter == orderNumberBeforeFilter

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[13]/a").click()
    wait_until_spinner_disappears_on_page()

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[7]/button").click()
    
    driver.find_element_by_xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/end-order-dialog/div[2]/button[1]").click()
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/div[3]/div[7]/button").click()
    #Check the dialog response
    time.sleep(2)
    dialogResponse=driver.find_element_by_xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/end-order-dialog/h2").text
    
    assert dialogResponse == "Do you you really want to end the order?"
    driver.find_element_by_xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/end-order-dialog/div[2]/button[2]").click()
    wait_until_spinner_disappears_on_page()
#SF-413
def test_sort_unit_field_in_mes():
    login()
    wait_until_spinner_disappears_on_page()
    #Click on Delivery List Tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[1]/app-header/div/ul/li[3]/a").click()
    wait_until_spinner_disappears_on_page()
    #Sort Accending order
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[11]/div/button").click()
    wait_until_spinner_disappears_on_page()
    unitElementsSortedAscending = [str(ele.text) for ele in driver.find_elements_by_xpath(
            "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[11]/span")]

    # assert unit ascending order sorting
    assert unitElementsSortedAscending == sorted(
        unitElementsSortedAscending)

    # sort orders by unit in Descending order
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[11]/div/button").click()

    wait_until_spinner_disappears_on_page()

    unitSortedDescending = [str(ele.text) for ele in driver.find_elements_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[11]/span")]

    # assert uniti descending order sorting
    assert unitSortedDescending == sorted(
        unitSortedDescending, reverse=True)

#SF-414
def test_list_of_filtered_order_by_production_line():
    login()
    wait_until_spinner_disappears_on_page()


    productionOrderBeforeFilter=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    productionLineNo=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr[1]/td[4]").text
    #Click filter tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/mat-expansion-panel-header").click()
    

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/form/div[1]/div[1]/mat-form-field/div/div[1]/div/input").send_keys(productionLineNo)
    #Apply filter
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[2]").click()
    wait_until_spinner_disappears_on_page()

    productionLineElements=driver.find_elements_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[4]")
    
    if len(productionLineElements) > 0:
    
        lineProduction = [
            str(ele.text) for ele in productionLineElements]

        for actual in lineProduction:
            assert actual == productionLineNo
    else:
        assert True

    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/mat-expansion-panel/div/div/div/button[1]").click()
    wait_until_spinner_disappears_on_page()
    productionOrderAfterFilter=driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/h3/span").text
    assert productionOrderAfterFilter == productionOrderBeforeFilter
#SF-416
def test_test_sort_quality_field_in_mes():
    login()
    wait_until_spinner_disappears_on_page()
    #Sort Accending order
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[7]/div/button").click()
    wait_until_spinner_disappears_on_page()
    qualityElementsSortedAscending = [str(ele.text) for ele in driver.find_elements_by_xpath(
            "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[7]/span")]

    # assert quality ascending order sorting
    assert qualityElementsSortedAscending == sorted(
        qualityElementsSortedAscending)

    # sort quality by unit in Descending order
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[7]/div/button").click()

    wait_until_spinner_disappears_on_page()

    qualityElementSortedDescending = [str(ele.text) for ele in driver.find_elements_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[7]/span")]

    # assert quality descending order sorting
    assert qualityElementSortedDescending == sorted(
        qualityElementSortedDescending, reverse=True)
#SF-418
def test_sort_destination_storage_type_field_in_mes():
    login()
    wait_until_spinner_disappears_on_page()
    #Click on Delivery List Tab
    driver.find_element_by_xpath("/html/body/app-root/div/div[1]/app-header/div/ul/li[3]/a").click()
    wait_until_spinner_disappears_on_page()
    #Sort Accending order
    driver.find_element_by_xpath("/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[16]/div/button").click()
    wait_until_spinner_disappears_on_page()
    destStorageElementsSortedAscending = [str(ele.text) for ele in driver.find_elements_by_xpath(
            "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[16]/span")]

    # assert unit ascending order sorting
    assert destStorageElementsSortedAscending == sorted(
        destStorageElementsSortedAscending)

    # sort orders by unit in Descending order
    driver.find_element_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/thead/tr/th[16]/div/button").click()

    wait_until_spinner_disappears_on_page()

    destStorageSortedDescending = [str(ele.text) for ele in driver.find_elements_by_xpath(
        "/html/body/app-root/div/div[2]/app-content/ng-component/div/table/tbody/tr/td[16]/span")]

    # assert uniti descending order sorting
    assert destStorageSortedDescending == sorted(
        destStorageSortedDescending, reverse=True)        







  
                                                        
