﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator
{
    public class calculator
    {
        public int Add (int a,int b)
        {
            return a + b;
        }

        public double Add_double(double a,double b)
        {
            return a + b;
        }
    }
}
