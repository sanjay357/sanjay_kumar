using System;
using Xunit;

namespace calculator_test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
