using Calculator;
using System;
using Xunit;

namespace Calculatortest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            Assert.True(true);
            Assert.Equal(1, 1);
        }
        [Fact]
        public void Add_Twovalue_Returnint()
        {
            //Arrange
          var calc = new calculator();
            //Act
            var result = calc.Add(1, 2);

            //Assert
            Assert.Equal(3, result);
        }
        [Fact]
        public void Add_Twovalue_Returndouble()
        {
            //Arrange
            var calc = new calculator();
            //Act
         
            var result = calc.Add_double(1, 2);

            //Assert
            Assert.Equal(3, result);
        }
    }
}
