using System;
using Xunit;

namespace Calculator_test1.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test_Add()
        {
            Assert.True(true);
        }
    }
}
